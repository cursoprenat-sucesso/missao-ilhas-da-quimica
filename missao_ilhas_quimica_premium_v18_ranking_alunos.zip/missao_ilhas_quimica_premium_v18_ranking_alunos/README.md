# PRENAT+ | Missão Ilhas da Química — V18

Versão no mesmo padrão da Natureza aprovada, com:

- cadastro do aluno antes de iniciar;
- nome completo, e-mail, apelido e turma;
- envio de acesso para Google Planilhas via Apps Script;
- envio de progresso por ilha para Google Planilhas;
- ranking/pódio no jogo do aluno;
- progresso salvo por aluno no navegador;
- importador CSV no professor;
- feedback positivo e negativo;
- backup automático;
- validação contra alternativas duplicadas;
- validação de exatamente uma alternativa correta.

## Links após subir no GitHub

Aluno:
https://cursoprenat-sucesso.github.io/missao-ilhas-da-quimica/?v=18

Professor:
https://cursoprenat-sucesso.github.io/missao-ilhas-da-quimica/professor.html?v=18
